# Plan before Action: Dynamic Programming

There are 3 programs are available.

* To understand MDP: `environment.py`
  * `python environment_demo.py`
* To understand Bellman Equation: `bellman_equation.py`
  * `python bellman_equation.py`
* To understand Dynamic Programming: `planner.py`
  * `python run_server.py`
  * You can simulate Dynamic Programming online!
